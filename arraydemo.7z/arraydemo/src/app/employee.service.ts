import { Injectable } from '@angular/core';
import { Employee } from './employee';

@Injectable({
  providedIn: 'root'
})
export class EmployeeService {
  employees:Employee[]=[
    {eid:113,name:"vamsi",salary:89636.677,gender:"male"},
    {eid:114,name:"lally",salary:56636.677,gender:"female"},
    {eid:105,name:"lalitha",salary:87636.677,gender:"female"},
    {eid:126,name:"sai",salary:98636.677,gender:"male"},
    {eid:137,name:"devi",salary:78636.677,gender:"female"}
    ];

  constructor() { }
  getAllEmployees():Employee[]{
    return this.employees;
  }
  addEmployee(employee:Employee){
    this.employees.push(employee);
    return true;
  }
  deleteEmployee(i:number){
    this.employees.splice(i,i);
    

  }
}
