import { Component, OnInit } from '@angular/core';
import { Employee } from '../employee';
import { EmployeeService } from '../employee.service';

@Component({
  selector: 'app-employeelist',
  templateUrl: './employeelist.component.html',
  styleUrls: ['./employeelist.component.css']
})
export class EmployeelistComponent implements OnInit {
employees:Employee[];

  constructor(private employeeService:EmployeeService) { }

  ngOnInit() {
    this.employees=this.employeeService.getAllEmployees();
  }
  delete(i:number){
    if(confirm("Are you sure to Delete?")){
    this.employeeService.deleteEmployee(i);
    console.log("Delete "+i+" Object");  
  }
  }

}
