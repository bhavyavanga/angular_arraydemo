export class Employee {
    eid:number;
    name:string;
    salary:number;
    gender:string;
    
}
